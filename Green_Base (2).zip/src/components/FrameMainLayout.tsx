import { FunctionComponent, useMemo, type CSSProperties } from "react";
import "./FrameMainLayout.css";

type FrameMainLayoutType = {
  /** Style props */
  propBoxShadow?: CSSProperties["boxShadow"];
  propBorder?: CSSProperties["border"];
  propBoxShadow1?: CSSProperties["boxShadow"];
  propBorder1?: CSSProperties["border"];
  propPadding?: CSSProperties["padding"];
  propPadding1?: CSSProperties["padding"];
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propBorderBottom?: CSSProperties["borderBottom"];
  propBorderBottom1?: CSSProperties["borderBottom"];
  propBackgroundColor1?: CSSProperties["backgroundColor"];
  propBorderBottom2?: CSSProperties["borderBottom"];
  propBorderBottom3?: CSSProperties["borderBottom"];
  propBackgroundColor2?: CSSProperties["backgroundColor"];
  propBorderBottom4?: CSSProperties["borderBottom"];
  propBorderBottom5?: CSSProperties["borderBottom"];
  propBackgroundColor3?: CSSProperties["backgroundColor"];
  propBorderBottom6?: CSSProperties["borderBottom"];
  propBorderBottom7?: CSSProperties["borderBottom"];
  propBackgroundColor4?: CSSProperties["backgroundColor"];
  propBoxShadow2?: CSSProperties["boxShadow"];
  propBorder2?: CSSProperties["border"];
  propBoxShadow3?: CSSProperties["boxShadow"];
  propBorder3?: CSSProperties["border"];
  propPadding2?: CSSProperties["padding"];
  propPadding3?: CSSProperties["padding"];
  propBackgroundColor5?: CSSProperties["backgroundColor"];
  propBorderBottom8?: CSSProperties["borderBottom"];
  propBorderBottom9?: CSSProperties["borderBottom"];
  propBackgroundColor6?: CSSProperties["backgroundColor"];
  propBorderBottom10?: CSSProperties["borderBottom"];
  propBorderBottom11?: CSSProperties["borderBottom"];
  propBackgroundColor7?: CSSProperties["backgroundColor"];
  propBorderBottom12?: CSSProperties["borderBottom"];
  propBorderBottom13?: CSSProperties["borderBottom"];
  propBackgroundColor8?: CSSProperties["backgroundColor"];
  propBorderBottom14?: CSSProperties["borderBottom"];
  propBorderBottom15?: CSSProperties["borderBottom"];
  propBackgroundColor9?: CSSProperties["backgroundColor"];
};

const FrameMainLayout: FunctionComponent<FrameMainLayoutType> = ({
  propBoxShadow,
  propBorder,
  propBoxShadow1,
  propBorder1,
  propPadding,
  propPadding1,
  propBackgroundColor,
  propBorderBottom,
  propBorderBottom1,
  propBackgroundColor1,
  propBorderBottom2,
  propBorderBottom3,
  propBackgroundColor2,
  propBorderBottom4,
  propBorderBottom5,
  propBackgroundColor3,
  propBorderBottom6,
  propBorderBottom7,
  propBackgroundColor4,
  propBoxShadow2,
  propBorder2,
  propBoxShadow3,
  propBorder3,
  propPadding2,
  propPadding3,
  propBackgroundColor5,
  propBorderBottom8,
  propBorderBottom9,
  propBackgroundColor6,
  propBorderBottom10,
  propBorderBottom11,
  propBackgroundColor7,
  propBorderBottom12,
  propBorderBottom13,
  propBackgroundColor8,
  propBorderBottom14,
  propBorderBottom15,
  propBackgroundColor9,
}) => {
  const recentTransactionsStyle: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow,
      border: propBorder,
    };
  }, [propBoxShadow, propBorder]);

  const rectangle4Style: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow1,
      border: propBorder1,
    };
  }, [propBoxShadow1, propBorder1]);

  const recentTransactionsTopProducStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const recentTransactionsHeaderRowStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  const line1Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
    };
  }, [propBackgroundColor]);

  const rowStyle: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom,
    };
  }, [propBorderBottom]);

  const bGStyle: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom1,
    };
  }, [propBorderBottom1]);

  const line2Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor1,
    };
  }, [propBackgroundColor1]);

  const row1Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom2,
    };
  }, [propBorderBottom2]);

  const bG1Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom3,
    };
  }, [propBorderBottom3]);

  const line3Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor2,
    };
  }, [propBackgroundColor2]);

  const row2Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom4,
    };
  }, [propBorderBottom4]);

  const bG2Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom5,
    };
  }, [propBorderBottom5]);

  const line4Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor3,
    };
  }, [propBackgroundColor3]);

  const row3Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom6,
    };
  }, [propBorderBottom6]);

  const bG3Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom7,
    };
  }, [propBorderBottom7]);

  const line5Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor4,
    };
  }, [propBackgroundColor4]);

  const topProductsStyle: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow2,
      border: propBorder2,
    };
  }, [propBoxShadow2, propBorder2]);

  const rectangle5Style: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow3,
      border: propBorder3,
    };
  }, [propBoxShadow3, propBorder3]);

  const frameDiv5Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding2,
    };
  }, [propPadding2]);

  const frameDiv6Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding3,
    };
  }, [propPadding3]);

  const line6Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor5,
    };
  }, [propBackgroundColor5]);

  const row4Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom8,
    };
  }, [propBorderBottom8]);

  const bG4Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom9,
    };
  }, [propBorderBottom9]);

  const line7Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor6,
    };
  }, [propBackgroundColor6]);

  const row5Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom10,
    };
  }, [propBorderBottom10]);

  const bG5Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom11,
    };
  }, [propBorderBottom11]);

  const line8Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor7,
    };
  }, [propBackgroundColor7]);

  const row6Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom12,
    };
  }, [propBorderBottom12]);

  const bG6Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom13,
    };
  }, [propBorderBottom13]);

  const line9Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor8,
    };
  }, [propBackgroundColor8]);

  const row7Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom14,
    };
  }, [propBorderBottom14]);

  const bG7Style: CSSProperties = useMemo(() => {
    return {
      borderBottom: propBorderBottom15,
    };
  }, [propBorderBottom15]);

  const line10Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor9,
    };
  }, [propBackgroundColor9]);

  return (
    <div className="frame-main-layout">
      <div className="recent-transactions2" style={recentTransactionsStyle}>
        <div className="rectangle88" style={rectangle4Style} />
        <div
          className="recent-transactions-top-produc1"
          style={recentTransactionsTopProducStyle}
        >
          <b className="recent-transactions3">Recent Transactions</b>
        </div>
        <div
          className="recent-transactions-header-row"
          style={recentTransactionsHeaderRowStyle}
        >
          <div className="header1">
            <div className="bg40" />
            <div className="column-one-column-two">
              <div className="product-name-frame">
                <div className="image-name-frame">
                  <div className="name28">Name</div>
                </div>
                <div className="column-two-column-one">
                  <div className="column-one6">Date</div>
                </div>
                <div className="column-two18">Amount</div>
                <div className="column-two19">Status</div>
              </div>
            </div>
            <div className="line17" style={line1Style} />
          </div>
          <div className="row14" style={rowStyle}>
            <div className="bg41" style={bGStyle} />
            <div className="line18" style={line2Style} />
            <div className="name29">Jessica S.</div>
            <div className="transaction-row-frame">
              <div className="text-label-product">24.05.2020</div>
            </div>
            <div className="column-frame">
              <div className="product-name-text">$124.97</div>
            </div>
            <div className="other03-badge01-light02-sma28">
              <div className="rectangle89" />
              <div className="badge28">Paid</div>
            </div>
          </div>
          <div className="row15" style={row1Style}>
            <div className="bg42" style={bG1Style} />
            <div className="line19" style={line3Style} />
            <div className="name30">Andrew S.</div>
            <div className="text-column-two">
              <div className="product-one-name">23.05.2020</div>
            </div>
            <div className="text-column-three">
              <div className="text44">$55.42</div>
            </div>
            <div className="other03-badge01-light02-sma29">
              <div className="rectangle90" />
              <div className="badge29">Pending</div>
            </div>
          </div>
          <div className="row16" style={row2Style}>
            <div className="bg43" style={bG2Style} />
            <div className="line20" style={line4Style} />
            <div className="name31">Kevin S.</div>
            <div className="green-small-badge-three">
              <div className="header-row">23.05.2020</div>
            </div>
            <div className="name-frame-column">
              <div className="text-frame-column">$89.90</div>
            </div>
            <div className="other03-badge01-light02-sma30">
              <div className="rectangle91" />
              <div className="badge30">Paid</div>
            </div>
          </div>
          <div className="row17" style={row3Style}>
            <div className="bg44" style={bG3Style} />
            <div className="line21" style={line5Style} />
            <div className="name32">Jack S.</div>
            <div className="text-wrapper">
              <div className="text45">22.05.2020</div>
            </div>
            <div className="text-frame">
              <div className="text46">$144.94</div>
            </div>
            <div className="other03-badge01-light02-sma31">
              <div className="rectangle92" />
              <div className="badge31">Pending</div>
            </div>
          </div>
          <div className="row18">
            <div className="bg45" />
            <div className="name33">Arthur S.</div>
            <div className="text-row">
              <div className="parent-frame">22.05.2020</div>
            </div>
            <div className="small-green-badge">
              <div className="final-frame">$70.52</div>
            </div>
            <div className="other03-badge01-light02-sma32">
              <div className="rectangle93" />
              <div className="badge32">Paid</div>
            </div>
          </div>
        </div>
      </div>
      <div className="top-products1" style={topProductsStyle}>
        <div className="rectangle94" style={rectangle5Style} />
        <div className="top-products-by-unit-wrapper" style={frameDiv5Style}>
          <b className="top-products-by">Top Products by Units Sold</b>
        </div>
        <div className="header-parent" style={frameDiv6Style}>
          <div className="header2">
            <div className="bg46" />
            <div className="header-inner">
              <div className="name-parent">
                <div className="name34">Name</div>
                <div className="column-two-parent">
                  <div className="column-two20">Price</div>
                  <div className="column-two21">Units Sold</div>
                </div>
              </div>
            </div>
            <div className="line22" style={line6Style} />
          </div>
          <div className="row19" style={row4Style}>
            <div className="bg47" style={bG4Style} />
            <div className="line23" style={line7Style} />
            <div className="image-parent">
              <img
                className="image-icon1"
                loading="eager"
                alt=""
                src="/image@2x.png"
              />
              <div className="name35">Men Grey Hoodie</div>
            </div>
            <div className="text-row-header-parent">
              <div className="text-row-header">$49.90</div>
              <div className="text-row-header1">204</div>
            </div>
          </div>
          <div className="row20" style={row5Style}>
            <div className="bg48" style={bG5Style} />
            <div className="line24" style={line8Style} />
            <div className="image-group">
              <img className="image-icon2" alt="" src="/image-1@2x.png" />
              <div className="name36">Women Striped T-Shirt</div>
            </div>
            <div className="product-two-text-parent">
              <div className="product-two-text">$34.90</div>
              <div className="product-two-text1">155</div>
            </div>
          </div>
          <div className="row21" style={row6Style}>
            <div className="bg49" style={bG6Style} />
            <div className="line25" style={line9Style} />
            <div className="image-container">
              <img className="image-icon3" alt="" src="/image-2@2x.png" />
              <div className="name37">Wome White T-Shirt</div>
            </div>
            <div className="name-image-column-parent">
              <div className="name-image-column">$40.90</div>
              <div className="name-image-column1">120</div>
            </div>
          </div>
          <div className="row22" style={row7Style}>
            <div className="bg50" style={bG7Style} />
            <div className="line26" style={line10Style} />
            <div className="image-parent1">
              <img className="image-icon4" alt="" src="/image-3@2x.png" />
              <div className="name38">Men White T-Shirt</div>
            </div>
            <div className="text-parent8">
              <div className="text47">$49.90</div>
              <div className="text48">204</div>
            </div>
          </div>
          <div className="row23">
            <div className="bg51" />
            <div className="image-parent2">
              <img className="image-icon5" alt="" src="/image-4@2x.png" />
              <div className="name39">Women Red T-Shirt</div>
            </div>
            <div className="child-texts-parent">
              <div className="child-texts">$34.90</div>
              <div className="child-texts1">155</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameMainLayout;
