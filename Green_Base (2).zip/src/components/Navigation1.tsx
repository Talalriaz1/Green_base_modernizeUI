import { FunctionComponent } from "react";
import "./Navigation1.css";

const Navigation1: FunctionComponent = () => {
  return (
    <div className="navigation">
      <div className="bg34" />
      <div className="column-two6">
        <div className="row-product">
          <div className="frame-product-info">
            <div className="type5" />
            <img className="icon1" loading="eager" alt="" src="/icon@2x.png" />
            <div className="name16">Dashboard</div>
          </div>
          <div className="frame-product-info1">
            <div className="type6" />
            <img
              className="general-01-icons-02-common2"
              alt=""
              src="/00-general--01-icons--02-common--32-list@2x.png"
            />
            <div className="name17">Orders</div>
          </div>
          <div className="top-products-header">
            <div className="column-one2">
              <div className="type7" />
              <img
                className="general-01-icons-05-financ"
                alt=""
                src="/00-general--01-icons--05-finance--08-tag@2x.png"
              />
              <div className="name18">Products</div>
            </div>
            <div className="column-one3">
              <div className="type8" />
              <img
                className="general-01-icons-03-files"
                alt=""
                src="/00-general--01-icons--03-files--01-folder@2x.png"
              />
              <div className="name19">Categories</div>
            </div>
            <div className="column-one4">
              <div className="type9" />
              <img
                className="general-01-icons-02-common3"
                alt=""
                src="/00-general--01-icons--02-common--03-users@2x.png"
              />
              <div className="name20">Customers</div>
            </div>
          </div>
          <div className="frame-product-info2">
            <div className="type10" />
            <img
              className="general-01-icons-02-common4"
              alt=""
              src="/00-general--01-icons--02-common--09-statistics@2x.png"
            />
            <div className="name21">Reports</div>
          </div>
          <div className="frame-product-info3">
            <div className="type11" />
            <img
              className="general-01-icons-02-common5"
              alt=""
              src="/00-general--01-icons--02-common--11-star@2x.png"
            />
            <div className="name22">Coupons</div>
          </div>
          <div className="frame-product-info4">
            <div className="type12" />
            <img
              className="general-01-icons-04-commun"
              alt=""
              src="/chat@2x.png"
            />
            <div className="name23">Inbox</div>
          </div>
        </div>
        <div className="text-amount">
          <div className="line-separator">
            <div className="category">Other Information</div>
          </div>
          <div className="frame-image">
            <button className="rectangle-background">
              <div className="type13" />
              <img
                className="general-01-icons-06-messag"
                alt=""
                src="/00-general--01-icons--06-messages--03-question@2x.png"
              />
              <div className="name24">Knowledge Base</div>
            </button>
            <button className="frame-name">
              <div className="type14" />
              <img
                className="general-01-icons-02-common6"
                alt=""
                src="/00-general--01-icons--02-common--29-ribbon@2x.png"
              />
              <div className="name25">Product Updates</div>
            </button>
          </div>
        </div>
        <div className="text-amount1">
          <div className="category-wrapper">
            <div className="category1">Settings</div>
          </div>
          <div className="parent">
            <button className="button">
              <div className="type15" />
              <img
                className="general-01-icons-02-common7"
                alt=""
                src="/00-general--01-icons--02-common--02-user@2x.png"
              />
              <div className="name26">Personal Settings</div>
            </button>
            <button className="button1">
              <div className="type16" />
              <img
                className="general-01-icons-02-common8"
                alt=""
                src="/00-general--01-icons--02-common--01-settings-2@2x.png"
              />
              <div className="name27">Global Settings</div>
            </button>
          </div>
        </div>
      </div>
      <div className="banner">
        <img
          className="illustration-icon1"
          loading="eager"
          alt=""
          src="/illustration.svg"
        />
        <div className="row-name-frame">
          <b className="grow-business">Grow Business</b>
          <div className="explore-our-marketin">
            Explore our marketing solutions
          </div>
        </div>
        <div className="frame-recent-transactions1">
          <button className="button01-regular-button03-sm">
            <div className="nameand-name">
              <div className="focus7" />
              <div className="type17" />
            </div>
            <div className="text42">
              <div className="row-name-frame-name-frame">
                <div className="frame-text">Read More</div>
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Navigation1;
