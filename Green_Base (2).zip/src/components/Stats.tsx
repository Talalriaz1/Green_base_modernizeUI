import { FunctionComponent, useMemo, type CSSProperties } from "react";
import "./Stats.css";

type StatsType = {
  card?: string;

  /** Style props */
  propBoxShadow?: CSSProperties["boxShadow"];
  propBorder?: CSSProperties["border"];
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propBackgroundColor1?: CSSProperties["backgroundColor"];
  propBackgroundColor2?: CSSProperties["backgroundColor"];
};

const Stats: FunctionComponent<StatsType> = ({
  card,
  propBoxShadow,
  propBorder,
  propBackgroundColor,
  propBackgroundColor1,
  propBackgroundColor2,
}) => {
  const statsStyle: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow,
      border: propBorder,
    };
  }, [propBoxShadow, propBorder]);

  const rectangleStyle: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
    };
  }, [propBackgroundColor]);

  const rectangle1Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor1,
    };
  }, [propBackgroundColor1]);

  const rectangle2Style: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor2,
    };
  }, [propBackgroundColor2]);

  return (
    <div className="stats" style={statsStyle}>
      <img className="card-icon" alt="" src={card} />
      <div className="column-two7">
        <div className="group">
          <b className="b">$10,540</b>
          <div className="total-revenue">Total Revenue</div>
        </div>
        <div className="container">
          <div className="div8">22.45%</div>
          <div className="general-01-icons-08-arrows1">
            <div className="bg35" />
            <img className="color-icon5" alt="" src="/color-1.svg" />
          </div>
        </div>
      </div>
      <div className="column-two8">
        <img className="icon2" alt="" src="/icon-1@2x.png" />
      </div>
      <div className="column-two9">
        <div className="rectangle72" style={rectangleStyle} />
      </div>
      <div className="column-two10">
        <div className="parent1">
          <b className="b1">1,056</b>
          <div className="orders3">Orders</div>
        </div>
        <div className="parent2">
          <div className="div9">15.34%</div>
          <div className="general-01-icons-08-arrows2">
            <div className="bg36" />
            <img className="color-icon6" alt="" src="/color-1.svg" />
          </div>
        </div>
      </div>
      <div className="column-two11">
        <img className="icon3" alt="" src="/icon-2@2x.png" />
      </div>
      <div className="column-two12">
        <div className="rectangle73" style={rectangle1Style} />
      </div>
      <div className="column-two13">
        <div className="parent3">
          <b className="b2">48</b>
          <div className="active-sessions">Active Sessions</div>
        </div>
        <div className="parent4">
          <div className="div10">18.25%</div>
          <div className="general-01-icons-08-arrows3">
            <div className="bg37" />
            <img className="color-icon7" alt="" src="/color-3.svg" />
          </div>
        </div>
      </div>
      <div className="column-two14">
        <img className="icon4" alt="" src="/icon-3@2x.png" />
      </div>
      <div className="column-two15">
        <div className="rectangle74" style={rectangle2Style} />
      </div>
      <div className="column-two16">
        <div className="parent5">
          <b className="b3">5,420</b>
          <div className="total-sessions">Total Sessions</div>
        </div>
        <div className="parent6">
          <div className="div11">10.24%</div>
          <div className="general-01-icons-08-arrows4">
            <div className="bg38" />
            <img className="color-icon8" alt="" src="/color-3.svg" />
          </div>
        </div>
      </div>
      <img className="icon5" alt="" src="/icon-4@2x.png" />
    </div>
  );
};

export default Stats;
