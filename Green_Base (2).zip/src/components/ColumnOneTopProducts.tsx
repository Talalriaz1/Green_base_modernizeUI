import { FunctionComponent, useMemo, type CSSProperties } from "react";
import "./ColumnOneTopProducts.css";

type ColumnOneTopProductsType = {
  /** Style props */
  propPadding?: CSSProperties["padding"];
};

const ColumnOneTopProducts: FunctionComponent<ColumnOneTopProductsType> = ({
  propPadding,
}) => {
  const columnOneTopProductsStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  return (
    <div className="column-one-top-products" style={columnOneTopProductsStyle}>
      <div className="column-two-top-products">
        <b className="title3">Orders Over Time</b>
        <div className="recent-transactions">
          <div className="recent-transactions-header">
            <b className="top-products">645</b>
            <div className="orders-on-may">Orders on May 22</div>
          </div>
          <div className="recent-transactions-header1">
            <b className="b4">472</b>
            <div className="orders-on-may1">Orders on May 21</div>
          </div>
        </div>
      </div>
      <div className="column-one5">
        <div className="column-two17" />
        <div className="line-separator1">
          <div className="row-transaction">
            <div className="last-12-hours">Last 12 Hours</div>
            <div className="icon6">
              <div className="bg39" />
              <img className="color-icon9" alt="" src="/color.svg" />
            </div>
          </div>
          <div className="frame-column-two">
            <div className="header-name-column-two">
              <div className="may-21">May 21</div>
            </div>
            <input className="other-badge-light-small-blue" type="checkbox" />
            <div className="may-22">May 22</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ColumnOneTopProducts;
