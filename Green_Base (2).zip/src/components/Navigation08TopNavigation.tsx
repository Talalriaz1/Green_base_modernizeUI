import { FunctionComponent } from "react";
import "./Navigation08TopNavigation.css";

const Navigation08TopNavigation: FunctionComponent = () => {
  return (
    <header className="navigation08-top-navigation0">
      <div className="rectangle71" />
      <div className="logo-parent">
        <div className="logo">
          <img
            className="group-icon2"
            loading="eager"
            alt=""
            src="/group.svg"
          />
          <div className="modernize">Modernize</div>
        </div>
        <div className="search">
          <img
            className="general-01-icons-02-common"
            alt=""
            src="/00-general--01-icons--02-common--01-settings@2x.png"
          />
          <div className="search1">Search...</div>
        </div>
      </div>
      <div className="image">
        <div className="line15">
          <img className="chat-icon" alt="" src="/chat@2x.png" />
          <div className="notifications">
            <img
              className="general-01-icons-02-common1"
              alt=""
              src="/00-general--01-icons--02-common--01-settings-1@2x.png"
            />
            <div className="other06-counter-circle03-sma">
              <div className="bg32" />
              <b className="value">5</b>
            </div>
          </div>
        </div>
        <div className="user">
          <img className="avatar-icon" alt="" src="/avatar@2x.png" />
          <div className="monica-simons-wrapper">
            <div className="monica-simons">X’eriya Ponald</div>
          </div>
          <div className="general-01-icons-08-arrows">
            <div className="bg33" />
            <img className="color-icon4" alt="" src="/color.svg" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navigation08TopNavigation;
