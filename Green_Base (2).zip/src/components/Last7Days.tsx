import { FunctionComponent, useMemo, type CSSProperties } from "react";
import "./Last7Days.css";

type Last7DaysType = {
  /** Style props */
  propBoxShadow?: CSSProperties["boxShadow"];
  propBorder?: CSSProperties["border"];
  propBoxShadow1?: CSSProperties["boxShadow"];
  propBorder1?: CSSProperties["border"];
  propPadding?: CSSProperties["padding"];
  propPadding1?: CSSProperties["padding"];
  propPadding2?: CSSProperties["padding"];
  propPadding3?: CSSProperties["padding"];
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propPadding4?: CSSProperties["padding"];
  propPadding5?: CSSProperties["padding"];
  propPadding6?: CSSProperties["padding"];
  propPadding7?: CSSProperties["padding"];
  propPadding8?: CSSProperties["padding"];
};

const Last7Days: FunctionComponent<Last7DaysType> = ({
  propBoxShadow,
  propBorder,
  propBoxShadow1,
  propBorder1,
  propPadding,
  propPadding1,
  propPadding2,
  propPadding3,
  propBackgroundColor,
  propPadding4,
  propPadding5,
  propPadding6,
  propPadding7,
  propPadding8,
}) => {
  const last7DaysStyle: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow,
      border: propBorder,
    };
  }, [propBoxShadow, propBorder]);

  const rectangle3Style: CSSProperties = useMemo(() => {
    return {
      boxShadow: propBoxShadow1,
      border: propBorder1,
    };
  }, [propBoxShadow1, propBorder1]);

  const headerTitleStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const rectangleSeparatorStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  const rectangleSeparator1Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding2,
    };
  }, [propPadding2]);

  const frameRecentTransactionsStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding3,
    };
  }, [propPadding3]);

  const lineStyle: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
    };
  }, [propBackgroundColor]);

  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding4,
    };
  }, [propPadding4]);

  const frameDiv1Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding5,
    };
  }, [propPadding5]);

  const frameDiv2Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding6,
    };
  }, [propPadding6]);

  const frameDiv3Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding7,
    };
  }, [propPadding7]);

  const frameDiv4Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding8,
    };
  }, [propPadding8]);

  return (
    <div className="last-7-days" style={last7DaysStyle}>
      <div className="rectangle75" style={rectangle3Style} />
      <div className="header-title" style={headerTitleStyle}>
        <b className="last-7-days1">Last 7 Days Sales</b>
      </div>
      <div className="rectangle-separator" style={rectangleSeparatorStyle}>
        <div className="background1">
          <b className="recent-transactions1">1,259</b>
          <div className="items-sold">Items Sold</div>
        </div>
      </div>
      <div className="rectangle-separator1" style={rectangleSeparator1Style}>
        <div className="parent7">
          <b className="b5">$12,546</b>
          <div className="revenue">Revenue</div>
        </div>
      </div>
      <div
        className="frame-recent-transactions2"
        style={frameRecentTransactionsStyle}
      >
        <div className="line16" style={lineStyle} />
      </div>
      <div className="last-7-days-inner" style={frameDivStyle}>
        <div className="frame-parent1">
          <div className="frame-header-parent">
            <div className="frame-header" />
            <div className="rectangle-parent1" style={frameDiv1Style}>
              <div className="rectangle76" />
              <div className="div12">12</div>
            </div>
          </div>
          <div className="rectangle-parent2">
            <div className="rectangle77" />
            <div className="rectangle-parent3">
              <div className="rectangle78" />
              <div className="div13">13</div>
            </div>
          </div>
          <div className="frame-transaction-list-parent">
            <button className="frame-transaction-list">
              <img className="bg-icon" alt="" src="/bg.svg" />
              <b className="text43">$2,525</b>
            </button>
            <div className="frame-products-parent">
              <div className="frame-products">
                <div className="rectangle79" />
                <div className="rectangle-parent4">
                  <div className="rectangle80" />
                  <div className="div14">14</div>
                </div>
              </div>
              <div className="frame-products1">
                <div className="rectangle81" />
                <div className="rectangle-parent5" style={frameDiv2Style}>
                  <div className="rectangle82" />
                  <div className="div15">15</div>
                </div>
              </div>
              <div className="rectangle-parent6">
                <div className="rectangle83" />
                <div className="text-footer">16</div>
              </div>
              <div className="rectangle-background1" />
            </div>
          </div>
          <div className="rectangle-parent7">
            <div className="rectangle84" />
            <div className="rectangle-parent8" style={frameDiv3Style}>
              <div className="rectangle85" />
              <div className="div16">17</div>
            </div>
          </div>
          <div className="rectangle-parent9">
            <div className="rectangle86" />
            <div className="rectangle-parent10" style={frameDiv4Style}>
              <div className="rectangle87" />
              <div className="div17">18</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Last7Days;
