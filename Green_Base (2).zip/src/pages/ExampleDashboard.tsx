import { FunctionComponent } from "react";
import Navigation08TopNavigation from "../components/Navigation08TopNavigation";
import Navigation1 from "../components/Navigation1";
import Stats from "../components/Stats";
import ColumnOneTopProducts from "../components/ColumnOneTopProducts";
import Last7Days from "../components/Last7Days";
import FrameMainLayout from "../components/FrameMainLayout";
import "./ExampleDashboard.css";

const ExampleDashboard: FunctionComponent = () => {
  return (
    <div className="example-dashboard">
      <Navigation08TopNavigation />
      <main className="text-product-name">
        <Navigation1 />
        <section className="other-badge-light-small-green">
          <div className="frame-grid">
            <div className="frame-textbox">
              <h2 className="dashboard">Dashboard</h2>
              <div className="button02-icon-button02-mediu">
                <div className="focus" />
                <div className="type" />
                <img className="group-icon" alt="" src="/group-1@2x.png" />
                <div className="text-type">Manage</div>
              </div>
            </div>
            <Stats card="/card.svg" />
            <div className="orders-chart-parent">
              <div className="orders-chart">
                <div className="bg" />
                <ColumnOneTopProducts />
                <div className="row-recent-product">
                  <div className="name-image-product">
                    <img className="line-icon" alt="" src="/line.svg" />
                    <img className="line-icon1" alt="" src="/line-1.svg" />
                  </div>
                </div>
                <div className="header-group">
                  <div className="frame-top">
                    <div className="frame-body">
                      <div className="rectangle" />
                      <div className="frame-footer">50</div>
                    </div>
                    <div className="rectangle-header" />
                  </div>
                  <div className="frame-top1">
                    <div className="rectangle-parent">
                      <div className="rectangle1" />
                      <div className="div">40</div>
                    </div>
                    <div className="rectangle2" />
                  </div>
                  <div className="text-title">
                    <div className="column-one">
                      <div className="column-two">
                        <div className="rectangle3" />
                        <div className="row-content">30</div>
                      </div>
                      <div className="column-two1">
                        <div className="rectangle4" />
                        <div className="div1">20</div>
                      </div>
                    </div>
                    <div className="name-product">
                      <input className="frame-product" type="text" />
                      <div className="frame-product1" />
                    </div>
                  </div>
                  <div className="frame-top2">
                    <div className="rectangle-group">
                      <div className="rectangle5" />
                      <div className="div2">10</div>
                    </div>
                    <div className="rectangle6" />
                  </div>
                  <div className="frame-top3">
                    <div className="rectangle-container">
                      <div className="rectangle7" />
                      <div className="div3">0</div>
                    </div>
                    <div className="rectangle8" />
                  </div>
                  <div className="image-icon">
                    <button className="text-label">
                      <div className="rectangle9" />
                      <div className="am">4am</div>
                    </button>
                    <button className="text-label1">
                      <div className="rectangle10" />
                      <div className="am1">5am</div>
                    </button>
                    <button className="text-label2">
                      <div className="rectangle11" />
                      <div className="am2">6am</div>
                    </button>
                    <button className="text-label3">
                      <div className="rectangle12" />
                      <div className="am3">7am</div>
                    </button>
                    <button className="text-label4">
                      <div className="rectangle13" />
                      <div className="am4">8am</div>
                    </button>
                    <button className="text-label5">
                      <div className="rectangle14" />
                      <div className="am5">9am</div>
                    </button>
                    <button className="text-label6">
                      <div className="rectangle15" />
                      <div className="am6">10am</div>
                    </button>
                    <button className="text-label7">
                      <div className="rectangle16" />
                      <div className="am7">11am</div>
                    </button>
                    <button className="text-label8">
                      <div className="rectangle17" />
                      <div className="am8">12am</div>
                    </button>
                    <button className="text-label9">
                      <div className="rectangle18" />
                      <div className="pm">1pm</div>
                    </button>
                    <button className="text-label10">
                      <div className="rectangle19" />
                      <div className="pm1">2pm</div>
                    </button>
                    <button className="text-label11">
                      <div className="rectangle20" />
                      <div className="pm2">3pm</div>
                    </button>
                  </div>
                </div>
              </div>
              <Last7Days />
            </div>
            <FrameMainLayout />
          </div>
        </section>
      </main>
    </div>
  );
};

export default ExampleDashboard;
